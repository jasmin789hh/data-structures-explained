# Data Structures Explained

A beginner-friendly repository demonstrating common data structures in Python.
Created by **Diwakr Reddy**, Computer Science Teacher at Sacred Heart School, Kalyan.

## Included Structures
- Stack
- Queue
- Linked List
- Binary Tree
- Graph (Basic)

Each structure includes:
- Clear implementation
- Comments for learning
- Example usage

